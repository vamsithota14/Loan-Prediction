
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import StandardScaler
import numpy as np # linear algebra
import os # accessing directory structure
import pandas as pd # 
import seaborn as sns #Graph library that use matplot in background
import matplotlib.pyplot as plt



df1 = pd.read_csv('D:\\loan prediction\\german_csv.csv', delimiter=',')
df1.dataframeName = 'german_credit_data.csv'
nRow, nCol = df1.shape
print(f'There are {nRow} rows and {nCol} columns')
df1.head(5)
#print(df1.info())

plt.figure(figsize=(14,12))
sns.heatmap(df1.astype(float).corr(),linewidths=0.1,vmax=1.0, square=True,  linecolor='white', annot=True)
plt.show()

from sklearn.model_selection import train_test_split, KFold, cross_val_score # to split the data
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, fbeta_score 

#Creating the X and y variables
X = df1.drop('Creditability', 1).values
y = df1["Creditability"].values

# Spliting X and y into train and test version
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state=42)



#model 1
'''
import statsmodels.api as sm
logit=sm.Logit(y,X)
logit_model=logit.fit()
print(logit_model.summary2())

'''
#Model 2

from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression(max_iter=1000)
logreg.fit(X_train,y_train)
# Printing the Training Score
print("Training score data: ")
print(logreg.score(X_train, y_train))

print("Testing score data: ")
y_pred = logreg.predict(X_test)
print(accuracy_score(y_test,y_pred))
print("\n")

print("classification_report: ")
from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))
print("confusion_matrix: ")
from sklearn import metrics
cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
print(cnf_matrix)




